<template>
  <div id="extensions">
    <div id="extensions-table-wrap" class="table-responsive pb-0">
      <div class="d-flex align-items-center pe-2">
        <h1>
          Extensiones
        </h1>

        <SearchForm
          :collection="extensions"
          v-show="extensions && extensions.length"
          v-model="results">
        </SearchForm>

        <a
          target="_blank"
          href="/extensions/export"
          class="ms-3 btn btn-sm btn-outline btn-outline-success">
          Exportar XLS
        </a>
      </div>
      <table class="table" v-if="results && results.length">
        <thead>
          <th>Apto.</th>
          <th>Mascotas</th>
          <th>Vehículos</th>
          <th>Útil</th>
          <th>Tel. propietario</th>
          <th>Citofonía 1</th>
          <th>Citofonía 2</th>
          <th class="text-right">Detalle</th>
        </thead>
        <tbody>
          <tr v-for="extension in results" :key="extension.id">
            <td>{{ extension.name }}</td>
            <td>{{ extension.pets_count }}</td>
            <td>{{ extension.vehicles ? extension.vehicles.length : 0 }}</td>
            <td>{{ (extension.has_deposit) ? 'SÍ' : 'NO' }}</td>
            <td>{{ extension.owner_phone }}</td>
            <td>{{ extension.phone_1 }}</td>
            <td>{{ extension.phone_2 }}</td>
            <td>
              <a :href="`/extensions/${extension.id}/visitors`">
                <i class="material-icons">lock_open</i>
              </a>
              <a :href="`/extensions/${extension.id}/edit`">
                <i class="material-icons">visibility</i>
              </a>
              <a href="#" @click="deleteExtension(extension.id)">
                <i class="material-icons">delete</i>
              </a>
            </td>
          </tr>
        </tbody>
      </table>
      <div class="alert alert-info" v-else>
        No hay extensiones disponibles para mostrar
      </div>
    </div>

    <div class="fab-container">
      <a href="/extensions/create" class="btn btn-primary btn-circle">
        <i class="material-icons">add</i>
      </a>
    </div>

  </div>
</template>

<script setup>
import { ref, onMounted } from 'vue'

const extensions = ref([])
const results = ref([])

const props = defineProps({
  items: {
    type: Array,
    default: () => ([])
  }
})

function deleteExtension(id) {
  if (!window.confirm('¿Seguro que quieres eliminar la extensión?')) return

  axios.delete(`/extensions/${id}`)
    .then(() => {
      extensions.value = extensions.value.filter(extension => extension.id != id)
      results.value    = [...extensions.value]
    })
    .catch(error => console.log(error.response.data))
}

onMounted(() => {
  extensions.value = [...props.items]
  results.value    = [...extensions.value]
})
</script>

<style>
.extensions-container {
  height: calc(100vh - 112px);
  position: relative;
  padding-bottom: 20px;
}

#extensions-table-wrap {
  height: calc(100% - 50px);
  margin-bottom: 10px;
  overflow: auto;
}

.filled {
  color: #06a906;
}

.empty {
  color: #c0392b;
}

table th:last-child,
table tr td:last-child {
  text-align: right;
}

.btn-export {
  font-size: 1em;
  font-weight: 400;
  color: darkgray;
  text-transform: none;
  border-radius: 5px;
  border: 1px solid lightgray;
  background: #fff;
  box-shadow: none;
  margin-right: 10px;
  height: 40px;
}
</style>


