<?php $__env->startSection('content'); ?>
  <div class="container">
    <create-extension :extension-id="null"/>
  </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/citofoni/laravel/resources/views/admin/extensions/create.blade.php ENDPATH**/ ?>