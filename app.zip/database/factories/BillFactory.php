<?php

/* @var $factory \Illuminate\Database\Eloquent\Factory */

use App\Bill;
use Faker\Generator as Faker;

$factory->define(Bill::class, function (Faker $faker) {
    return [
        //
    ];
});
