<?php

/* @var $factory \Illuminate\Database\Eloquent\Factory */

use App\Petition;
use Faker\Generator as Faker;

$factory->define(Petition::class, function (Faker $faker) {
    return [
        //
    ];
});
