<?php

/* @var $factory \Illuminate\Database\Eloquent\Factory */

use App\Novelty;
use Faker\Generator as Faker;

$factory->define(Novelty::class, function (Faker $faker) {
    return [
        //
    ];
});
