<?php $__env->startSection('styles'); ?>
<style>
    .picture-placeholder, .avatar {
        width: 40px;
        height: 40px;
        border-radius: 50%;
        background: grey;
    }
</style>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<div class="container">
  <div class="table-responsive">
    <h1>
      Visitas al conjunto residencial
    </h1>
    <table class="table">
      <thead>
        <th>Foto</th>
        <th>Apto</th>
        <th>Cédula</th>
        <th>Nombre</th>
        <th>Empresa</th>
        <th>ARL-EPS</th>
        <th>Entrada</th>
        <th>Salida</th>
      </thead>
      <tbody>
        <?php $__currentLoopData = $visits; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $visit): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <tr>
            <td>
                <?php if( $url = $visit->getFirstMediaUrl('picture') ): ?>
                    <a href="<?php echo e($url); ?>" target="_blank">
                        <img src="<?php echo e($url); ?>" class="avatar"/>
                    </a>
                <?php else: ?>
                    <div class="picture-placeholder"></div>
                <?php endif; ?>
            </td>
            <td><?php echo e($visit->extension?->name); ?></td>
            <td><?php echo e($visit->dni); ?></td>
            <td><?php echo e($visit->name); ?></td>
            <td><?php echo e($visit->company); ?></td>
            <td><?php echo e($visit->arl_eps); ?></td>
            <td><?php echo e($visit->checkin); ?></td>
            <td><?php echo e($visit->checkout); ?></td>
          </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </tbody>
    </table>
  </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/citofoni/laravel/resources/views/admin/visits.blade.php ENDPATH**/ ?>