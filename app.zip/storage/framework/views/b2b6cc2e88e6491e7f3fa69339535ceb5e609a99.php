  <?php $__env->startSection('styles'); ?>
    <style>
      .dasboard-section-title {
        margin-left: -45px;
        display: flex;
        align-items: center;
      }
      .dashboard-section-title a {
        margin-right: 15px;
        text-decoration: none;
      }
    </style>
  <?php $__env->stopSection(); ?>
  <?php $__env->startSection('content'); ?>
  <div class="container">
  <div class="row">
    <div class="col-md-6 mx-auto">
      <?php if( session('message') ): ?>
      <div class="alert alert-success">
        <?php echo e(session('message')); ?>

      </div>
      <?php endif; ?>
      <h1>
        <a href="<?php echo e(route('admin.admins.index')); ?>">
          <i class="material-icons">
            arrow_back
          </i>
        </a>
        <?php echo e($admin->name); ?>

      </h1>
      <?php if( $modules->count() ): ?>
      <div class="form-section-title">
        Módulos Disponibles
      </div>
      <form action="<?php echo e(route('admin.admins.update-permissions', ['admin'=>$admin->id])); ?>" method="POST">
        <?php echo csrf_field(); ?>
        <?php echo method_field('PUT'); ?>
        <ul class="list-group mb-4 p-0">
          <?php $__currentLoopData = $modules; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $module): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <li class="list-group-item">

            <div class="custom-control custom-switch">
              <input
                type="checkbox"
                name="modules[]"
                value="<?php echo e($module->id); ?>"
                id="switch<?php echo e($loop->index); ?>"
                class="custom-control-input"
                <?php if( $admin->modules->find( $module->id ) ): ?>
                  checked
                <?php endif; ?>
              >
              <label class="custom-control-label" for="switch<?php echo e($loop->index); ?>">
              <?php echo e($module->name); ?>

              </label>
            </div>
          </li>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
        <div class="card">
          <div class="card-body">
            <button type="submit" class="btn btn-primary">
              Actualizar
            </button>
          </div>
        </div>
      </form>
      <?php else: ?>
      <div class="alert alert-info">
        No hay módulos registrados aún
      </div>
      <?php endif; ?>
    </div><!-- end col-md-6 -->
  </div><!-- end row -->
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.super', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/citofoni/laravel/resources/views/super/admins/edit-permissions.blade.php ENDPATH**/ ?>