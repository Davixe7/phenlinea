<?php $__env->startSection('content'); ?>
<div class="container">
    <porterias
        :rows="<?php echo e(json_encode( $porterias )); ?>"
        :admins="<?php echo e(json_encode( $admins )); ?>">
    </porterias>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.super', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/citofoni/laravel/resources/views/super/porterias/index.blade.php ENDPATH**/ ?>