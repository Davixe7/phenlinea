@extends('layouts.app')
@section('content')
  <div class="container">
    <div class="text-center d-flex flex-column align-items-center justify-content-center" style="height: calc(100vh - 68px);">
      <h3>Cuenta suspendida</h3>
      Su cuenta ha sido suspendida por falta de pago<br>
      +573006050430 | +573144379170<br>
      info@ietecno.com
    </div>
  </div>
@endsection
