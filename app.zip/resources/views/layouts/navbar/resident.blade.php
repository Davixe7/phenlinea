<li class="nav-item">
  <a class="nav-link" href="{{ route('home') }}">Cartelera</a>
</li>
<li class="nav-item">
  <a class="nav-link" href="{{ route('docs.index') }}">Manuales & documentos</a>
</li>
<li class="nav-item">
  <a class="nav-link" href="{{ route('reminders.index') }}">Notificaciones</a>
</li>
<li class="nav-item">
  <a class="nav-link" href="{{ route('petitions.index') }}">Solicitudes</a>
</li>
<li class="nav-item">
  <a class="nav-link" href="{{ route('bills.index') }}">Enlaces</a>
</li>
<li class="nav-item">
  <a class="nav-link" href="/mis-facturas">Mis facturas</a>
</li>