<li class="nav-item">
  <a class="nav-link" href="<?php echo e(route('admin.users.index')); ?>">SuperUsuarios</a>
</li>
<li class="nav-item">
  <a class="nav-link" href="<?php echo e(route('admin.admins.index')); ?>">Administradores</a>
</li>
<li class="nav-item">
  <a class="nav-link" href="<?php echo e(route('admin.porterias.index')); ?>">Porterias</a>
</li>
<li class="nav-item">
  <a class="nav-link" href="<?php echo e(route('admin.invoices.upload')); ?>">Facturas</a>
</li>
<li class="nav-item">
  <a class="nav-link" href="<?php echo e(route('admin.documentos.index')); ?>">Documentos Legales</a>
</li><?php /**PATH /home/citofoni/laravel/resources/views/layouts/navbar/super.blade.php ENDPATH**/ ?>