<?php $__env->startSection('styles'); ?>
<style>
  .form-group label {
    display: block;
    font-size: 1.2em;
    font-weight: 500;
    color: #0075ff;
    margin: 0 0 20px 0 !important;
  }
</style>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<div class="container">
  <?php if( Session::has('message') ): ?>
  <div class="alert alert-success">
    <?php echo e(Session::get('message')); ?>

  </div>
  <?php endif; ?>
  <div class="page-title">
    <h1>
      Documentos legales
    </h1>
  </div>
  <div class="row">
    <div class="col-md-4">
      <div class="card">
        <div class="card-body">
          <form action="<?php echo e(route('admin.documentos.store')); ?>" method="POST" enctype="multipart/form-data">
            <?php echo csrf_field(); ?>
            <div class="form-group">
              <label for="rut">
                1. RUT
              </label>
              <input type="file" class="form-control-file" name="file" required>
            </div>
            <input type="hidden" name="filename" value="RUT">
            <div class="form-group text-right">
              <v-btn dark type="submit" class="w-100">
                enviar
              </v-btn>
            </div>
          </form>
        </div>
      </div>
    </div>

    <div class="col-md-4">
      <div class="card">
        <div class="card-body">
          <form action="<?php echo e(route('admin.documentos.store')); ?>" method="POST" enctype="multipart/form-data">
            <?php echo csrf_field(); ?>
            <div class="form-group">
              <label for="rut">
                2. SEGURIDAD SOCIAL
              </label>
              <input type="file" class="form-control-file" name="file" required>
            </div>
            <input type="hidden" name="filename" value="SEGURIDAD_SOCIAL">
            <div class="form-group text-right">
              <v-btn dark type="submit" class="w-100">
                enviar
              </v-btn>
            </div>
          </form>
        </div>
      </div>
    </div>

    <div class="col-md-4">
      <div class="card">
        <div class="card-body">
          <form action="<?php echo e(route('admin.documentos.store')); ?>" method="POST" enctype="multipart/form-data">
            <?php echo csrf_field(); ?>
            <div class="form-group">
              <label for="rut">
                3. CERTIFICADO BANCARIO
              </label>
              <input type="file" class="form-control-file" name="file" required>
            </div>
            <input type="hidden" name="filename" value="CERTIFICADO_BANCARIO">
            <div class="form-group text-right">
              <v-btn dark type="submit" class="w-100">
                enviar
              </v-btn>
            </div>
          </form>
        </div>
      </div>
    </div>
  </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.super', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/citofoni/laravel/resources/views/super/documentos/index.blade.php ENDPATH**/ ?>