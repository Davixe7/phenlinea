@extends('layouts.app')
@section('content')
<div class="container d-flex align-items-center justify-content-center" style="height: calc(100vh - 100px);">
    <a href="/apk" class="btn btn-success">Descargar APK</a>
</div>
@endsection