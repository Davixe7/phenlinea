<?php $__env->startSection('styles'); ?>
<style>
    .table-responsive {
      max-height: calc(100vh - 100px);
    }
</style>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="container">
  <admins :admins="<?php echo e(json_encode( $admins )); ?>"></admins>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.super', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/citofoni/laravel/resources/views/super/admins/index.blade.php ENDPATH**/ ?>