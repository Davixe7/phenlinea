<?php

/* @var $factory \Illuminate\Database\Eloquent\Factory */

use App\Resident;
use Faker\Generator as Faker;

$factory->define(Resident::class, function (Faker $faker) {
    return [
        //
    ];
});
