<?php $__env->startSection('content'); ?>
<div class="container">
  <Users :users="<?php echo e(json_encode($users)); ?>"></Users>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.super', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/citofoni/laravel/resources/views/super/users/index.blade.php ENDPATH**/ ?>