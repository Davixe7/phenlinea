<li>
  <a href="{{ route('extensions.index') }}">Extensiones</a>
</li>
<li>
  <a href="{{ route('novelties.index') }}">Novedades</a>
</li>
<li>
  <a href="{{ route('pqrs.index') }}">PQRS</a>
</li>
<li>
  <a href="{{ route('visits.index') }}">Visitas</a>
</li>
<li>
  <a href="{{ route('invoices.index') }}" v-pre>
    Facturas <span>PSE</span> <img src="https://corbanca.com.co/wp-content/uploads/2022/06/pse.png" style="width: 60px;">
  </a>
</li>
<li>
  <a href="{{ route('whatsapp.index') }}">
    <span class="mr-2">Mensajes Whatsapp</span>
    <img src="/img/icons8-whatsapp.svg" style="width: 20px; height: 20px;">
  </a>
</li>