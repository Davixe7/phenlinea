<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
  <title><?php echo e(config('app.name', 'PHenlinea')); ?></title>
  <link rel="dns-prefetch" href="//fonts.gstatic.com">
  <link href="/img/favicon.png" rel="icon">  
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet">
  <link href="<?php echo e(mix('css/app.css')); ?>" rel="stylesheet">
  <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
  <link href="https://fonts.googleapis.com/css?family=Roboto:400,500,600,700" rel="stylesheet">
  <?php echo $__env->yieldContent('styles'); ?>
</head>

<body>
  <main>
    <div id="app" data-app>
      <?php echo $__env->make('layouts.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
          <?php if( session('message') ): ?>
          <div class="alert text-center alert-<?php echo e(session('message_type') ?: 'info'); ?>">
            <?php echo e(session('message')); ?>

          </div>
          <?php endif; ?>
          <?php echo $__env->yieldContent('content'); ?>
    </div>
  </main>
  <script src="<?php echo e(mix('js/super.js')); ?>" defer></script>
  <?php echo $__env->yieldContent('scripts'); ?>
</body>

</html>
<?php /**PATH /home/citofoni/laravel/resources/views/layouts/super.blade.php ENDPATH**/ ?>