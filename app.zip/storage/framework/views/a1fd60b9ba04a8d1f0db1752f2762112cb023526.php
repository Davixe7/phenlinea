<?php $__env->startSection('styles'); ?>
<style>
  .table-responsive h1 {
    padding: 30px;
  }

  .card-body {
    padding: 0 30px;
  }

  .form-group {
    margin-bottom: 35px;
  }

  .material-form .form-group label {
    display: block;
    font-size: 14px;
    margin-bottom: 10px;
  }

  .material-form .form-group .form-control {
    font-size: 16px;
    padding: 0;
    border: none;
    border-bottom: 1px solid #000;
    border-radius: 0;
    background: none;
  }

  .material-form .form-group .form-control:focus {
    border-bottom: 1px solid var(--primary);
    box-shadow: none;
  }

  .navbar.navbar-light {
    background: #4B7094;
    color: #fff;
  }

  .navbar.navbar-light a {
    color: #fff !important;
  }

  .form-check-label {
    display: flex;
    align-items: center;
    margin-right: 1rem;
  }

  .form-check-label input.form-control {
    width: 17px;
    height: 17px;
    margin-right: .35rem;
  }
  .badge {
      padding: 3px 10px;
      border-radius: 5px;
      font-weight: 500;
      font-size: .85rem !important;
      height: fit-content;
  }
  .media-wrapper img {
      padding: .25em;
      border: 1px solid cadetblue;
      cursor: pointer;
  }
</style>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<div class="container" style="max-width: 480px;">
  <div class="table-responsive mt-5 pb-1">
    <div class="d-flex align-items-center justify-space-between">
      <h1>
        Detalle del PQRS
      </h1>
      
      <?php if( $pqrs->status == 'pending' ): ?>
      <div class="bg-secondary text-white badge">
          Pendiente
      </div>
      <?php elseif( $pqrs->status == 'read' ): ?>
      <div class="bg-info text-white badge">
          Leido
      </div>
      <?php else: ?>
      <div class="bg-success text-white badge">
          Respuesta enviada
      </div>
      <?php endif; ?>
      
      <div class="px-5">
        <b>
          <?php echo e(str_pad( $pqrs->id, 4, '0', STR_PAD_LEFT )); ?>

        </b>
      </div>
    </div>
    <div class="card-body material-form">
     <?php if( auth()->check('admin') ): ?>
        <div class="form-group">
        <label>Unidad Residencial</label>
        <input class="form-control" type="text" value="<?php echo e($pqrs->admin->name); ?>" disabled>
        </div>
        <div class="form-group">
        <label>Nro Apartamento. (opcional)</label>
        <input class="form-control" type="text" name="apto" value="<?php echo e($pqrs->apto); ?>">
        </div>
        <div class="form-group">
        <label>Nombre y apellidos</label>
        <input class="form-control" type="text" name="name" value="<?php echo e($pqrs->name); ?>">
        </div>
        <div class="row">
        <div class="form-group col-lg-6">
        <label>Teléfono 1</label>
        <input class="form-control" type="tel" name="phone" value="<?php echo e($pqrs->phone); ?>">
        </div>
        <div class="form-group col-lg-6">
        <label>Teléfono 2 (opcional)</label>
        <input class="form-control" type="tel" name="phone_2" value="<?php echo e($pqrs->phone_2); ?>">
        </div>
        </div>
        <div class="form-group">
        <label>Descripción</label>
        <textarea class="form-control" name="description" required><?php echo e($pqrs->description); ?></textarea>
        </div>
      
        <?php if( $attachments && count( $attachments ) ): ?>
            <div class="form-group row">
            <?php $__currentLoopData = $pqrs->getMedia('attachments'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $media): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="col-4 col-lg-3 media-wrapper" @click="showImg( <?php echo e($loop->index); ?> )">
                <img src="<?php echo e($media->original_url); ?>" style="width: 100%;">
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        <?php endif; ?>
      
      <?php elseif( $pqrs->answer ): ?>
       <div class="form-group">
        <label>Respuesta</label>
        <textarea class="form-control" name="description" required><?php echo e($pqrs->answer); ?></textarea>
      </div>
     <?php endif; ?>
     
      <?php if( auth()->check('admin') ): ?>
      <form action="<?php echo e(route('petitions.update', ['petition'=>$pqrs->id])); ?>" method="POST">
        <div class="d-flex">
          <?php echo csrf_field(); ?>
          <?php echo method_field('PUT'); ?>
        </div>
        <div class="form-group">
            <label>Respuesta</label>
            <textarea class="form-control" name="answer">
                <?php echo e($pqrs->answer); ?>

            </textarea>
        </div>
        <div class="text-right">
          <button class="btn btn-secondary text-white" type="submit">
            Actualizar
          </button>
        </div>
      </form>
      <?php endif; ?>
    </div>
  </div>
</div>

<vue-easy-lightbox :visible="visibleRef" :imgs="imgs" :index="indexRef" @hide="onHide">
</vue-easy-lightbox>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
<script src="https://unpkg.com/vue@next"></script>
<script src="https://unpkg.com/vue-easy-lightbox@next/dist/vue-easy-lightbox.umd.min.js"></script>
<script>
const app = Vue.createApp({
    setup() {
        const visibleRef = Vue.ref(false)
        const indexRef = Vue.ref(0)
        const imgs = <?php echo json_encode( $attachments , 15, 512) ?> 
        const showImg = (index) => {
            indexRef.value = index
            visibleRef.value = true
        }
        const onHide = () => visibleRef.value = false
        return {
            visibleRef,
            indexRef,
            imgs,
            showImg,
            onHide
        }
    }
})
  app.use(VueEasyLightbox) // global variable
  app.mount('#app')
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.legacy', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/citofoni/laravel/resources/views/public/pqrs/show.blade.php ENDPATH**/ ?>