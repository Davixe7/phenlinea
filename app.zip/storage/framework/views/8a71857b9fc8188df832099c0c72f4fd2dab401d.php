<li>
  <a href="<?php echo e(route('extensions.index')); ?>">Extensiones</a>
</li>
<li>
  <a href="<?php echo e(route('novelties.index')); ?>">Novedades</a>
</li>
<li>
  <a href="<?php echo e(route('pqrs.index')); ?>">PQRS</a>
</li>
<li>
  <a href="<?php echo e(route('visits.index')); ?>">Visitas</a>
</li>
<li>
  <a href="<?php echo e(route('invoices.index')); ?>" v-pre>
    Facturas <span>PSE</span> <img src="https://corbanca.com.co/wp-content/uploads/2022/06/pse.png" style="width: 60px;">
  </a>
</li>
<li>
  <a href="<?php echo e(route('whatsapp.index')); ?>">
    <span class="mr-2">Mensajes Whatsapp</span>
    <img src="/img/icons8-whatsapp.svg" style="width: 20px; height: 20px;">
  </a>
</li><?php /**PATH /home/citofoni/laravel/resources/views/layouts/navbar/admin.blade.php ENDPATH**/ ?>