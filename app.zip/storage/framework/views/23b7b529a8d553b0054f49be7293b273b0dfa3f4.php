<?php $__env->startSection('content'); ?>
  <div class="container" style="box-shadow: none;">
    <div class="col-md-5 mx-auto">
      <h1>Exportar Excel</h1>
      <div style="color: #919191;">
        <p>Descargara un reporte de todas las extensiones y residentes asociados a una unidad, en un archivo excel en formato XLSX</p>
      </div>
      <residents-export :admins="<?php echo e(json_encode($admins)); ?>"/>
    </div>
  </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.super', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/citofoni/laravel/resources/views/super/admins/export.blade.php ENDPATH**/ ?>