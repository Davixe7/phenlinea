@extends('layouts.legacy')
@section('content')
<div class="container">
    <h1>429</h1>
</div>
@endsection