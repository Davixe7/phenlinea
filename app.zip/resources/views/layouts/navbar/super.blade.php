<li class="nav-item">
  <a class="nav-link" href="{{ route('admin.users.index') }}">SuperUsuarios</a>
</li>
<li class="nav-item">
  <a class="nav-link" href="{{ route('admin.admins.index') }}">Administradores</a>
</li>
<li class="nav-item">
  <a class="nav-link" href="{{ route('admin.porterias.index') }}">Porterias</a>
</li>
<li class="nav-item">
  <a class="nav-link" href="{{ route('admin.invoices.upload') }}">Facturas</a>
</li>
<li class="nav-item">
  <a class="nav-link" href="{{ route('admin.documentos.index') }}">Documentos Legales</a>
</li>