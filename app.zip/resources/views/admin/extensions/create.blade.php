@extends('layouts.app')
@section('content')
  <div class="container">
    <create-extension :extension-id="null"/>
  </div>
@endsection