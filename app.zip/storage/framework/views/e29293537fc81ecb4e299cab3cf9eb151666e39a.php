<?php $__env->startSection('styles'); ?>
<style>
  .file-input {
    border: 2px solid green;
    height: 43px;
  }

  button {
    color: #fff !important;
    word-wrap: normal;
    white-space: nowrap;
  }

  label {
    font-size: .9em;
    font-weight: 500;
  }

  h6 {
    padding: 20px;
    margin: -12px -20px 20px -20px;
    border-bottom: 1px solid lightgray;
  }

  .list-group-item {
    padding-bottom: 30px;
  }
  .pill {
      display: inline-block;
      padding: .25rem .75rem;
      font-size: .8rem;
      font-weight: 400;
      background: lightgray;
      color: #242424;
      border: none;
  }
  .pill-pagado {
      background: lightgreen;
      color: green;
  }
  .fab {
      width: 60px;
      height: 60px;
      border: none;
      border-radius: 50%;
      outline: none;
      position: fixed;
      bottom: 30px;
      right: 30px;
      color: #fff;
      background: #3490dc;
  }
</style>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="container">

<Upload
    :rows="<?php echo e(json_encode( $invoices )); ?>"
    :month="<?php echo e($month); ?>"
    :year="<?php echo e($year); ?>"
    :months-name="<?php echo e(json_encode($monthsName)); ?>">
</Upload>

</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.super', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/citofoni/laravel/resources/views/super/invoices/import.blade.php ENDPATH**/ ?>